#!/bin/bash
find /usr/lib/ -name libGL.so;
find /usr/lib/ -name libGLU.so;
find /usr/lib/ -name libglut.so;
find /usr/include/ -name gl.h;
find /usr/include/ -name glu.h;
find /usr/include/ -name glut.h;


